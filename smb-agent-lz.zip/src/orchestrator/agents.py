from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class AgentResult:
    name: str
    output: Dict[str, Any]


class BaseAgent:
    name: str

    def run(self, context: Dict[str, Any]) -> AgentResult:
        raise NotImplementedError


class FinanceAgent(BaseAgent):
    name = "finance"

    def run(self, context: Dict[str, Any]) -> AgentResult:
        pulse = context["tool_calls"].get("pulse")
        out = {
            "cash_watch": pulse.get("risks", []),
            "recommended_actions": pulse.get("actions", []),
        }
        return AgentResult(self.name, out)


class CommsAgent(BaseAgent):
    name = "comms"

    def run(self, context: Dict[str, Any]) -> AgentResult:
        brief = context["tool_calls"].get("brief")
        out = {
            "message_bullets": brief.get("bullets", []),
        }
        return AgentResult(self.name, out)


class OrchestratorAgent(BaseAgent):
    name = "orchestrator"

    def __init__(self, agents: List[BaseAgent]):
        self.agents = agents

    def run(self, context: Dict[str, Any]) -> AgentResult:
        results = {}
        for a in self.agents:
            r = a.run(context)
            results[r.name] = r.output
        return AgentResult(self.name, results)
