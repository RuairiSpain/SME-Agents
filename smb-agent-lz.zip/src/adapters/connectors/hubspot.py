from __future__ import annotations

from typing import Any, Dict


def GetPipeline(arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    deals = [
        {"deal": "Expansion - North", "value": 5000, "stage": "proposal"},
        {"deal": "New logo - Retail", "value": 2000, "stage": "negotiation"},
    ]
    return {
        "pipeline_data": deals,
        "pipeline_total": sum(d["value"] for d in deals),
    }
