from __future__ import annotations

from typing import Any, Dict

import yaml

RUBRIC_PATH = "config/eval_rubric.yaml"


def _load_rubric() -> Dict[str, Any]:
    with open(RUBRIC_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def score_output(arguments: Dict[str, Any]) -> Dict[str, Any]:
    rubric = _load_rubric()["rubric"]
    dims = rubric["dimensions"]

    # Deterministic baseline scoring: this is intentionally simple and explainable.
    # You can replace it with LLM judging later.
    scores = {k: 4 for k in dims.keys()}

    output = arguments.get("output", {})

    # completeness: crude check - non-empty output
    if not isinstance(output, dict) or len(output) == 0:
        scores["completeness"] = 2

    # actionability: look for typical keys
    if isinstance(output, dict):
        has_actions = any(k in output for k in ["actions", "next_steps", "bullets"]) or (
            isinstance(output.get("brief"), dict) and "bullets" in output.get("brief", {})
        )
        if not has_actions:
            scores["actionability"] = 3

    avg = sum(scores.values()) / len(scores)
    pass_criteria = rubric["pass_criteria"]
    passed = avg >= pass_criteria["min_average"] and min(scores.values()) >= pass_criteria["min_dimension_score"]

    return {
        "skill_name": arguments.get("skill_name"),
        "scores": scores,
        "average": round(avg, 2),
        "pass": passed,
        "notes": "Deterministic rubric scorer (replace with LLM judging if desired).",
    }
