from __future__ import annotations

from typing import Any, Dict, List


def FridayBrief(arguments: Dict[str, Any]) -> Dict[str, Any]:
    activities = arguments.get("activities", [])
    metrics = arguments.get("metrics", {})

    wins = []
    risks = []
    priorities = []

    if activities:
        wins.append(f"Completed {len(activities)} tracked activities")

    cash = metrics.get("cash_balance")
    if cash is not None and float(cash) < 1000:
        risks.append("Cash is trending low")
        priorities.append("Prioritise collections and review spend")

    pipeline_total = metrics.get("pipeline_total")
    if pipeline_total is not None:
        priorities.append(f"Push pipeline value of {pipeline_total} with next-step commitments")

    bullets = []
    bullets.extend([f"Win: {w}" for w in wins] or ["Win: No major wins logged"])
    bullets.extend([f"Risk: {r}" for r in risks] or ["Risk: No major risks logged"])
    bullets.extend([f"Next: {p}" for p in priorities] or ["Next: Pick 3 priorities for next week"])

    return {
        "bullets": bullets,
        "metrics": metrics,
    }
