from __future__ import annotations

from typing import Any, Dict, List


def BusinessPulse(arguments: Dict[str, Any]) -> Dict[str, Any]:
    revenue = arguments["revenue_data"]
    pipeline = arguments["pipeline_data"]
    cash = float(arguments["cash_balance"])

    rev_n = len(revenue)
    pipe_n = len(pipeline)

    risks: List[str] = []
    actions: List[str] = []

    if cash < 1000:
        risks.append("Cash buffer is low")
        actions.append("Run invoice chase and delay discretionary spend")

    if pipe_n == 0:
        risks.append("Pipeline is empty")
        actions.append("Create 5 outbound touches and refresh referral asks")

    summary = f"Revenue entries: {rev_n}. Pipeline entries: {pipe_n}. Cash balance: {cash:.0f}."

    return {
        "summary": summary,
        "risks": risks,
        "actions": actions,
    }
