from __future__ import annotations

from typing import Any, Dict, List


def InvoiceChase(arguments: Dict[str, Any]) -> Dict[str, Any]:
    invoices = arguments["invoices"]
    customer = arguments["customer_name"]

    overdue = [i for i in invoices if i.get("days_overdue", 0) > 0]
    overdue_sorted = sorted(overdue, key=lambda x: (x.get("days_overdue", 0), x.get("amount", 0)), reverse=True)

    top = overdue_sorted[:3]
    escalation = any(i.get("days_overdue", 0) >= 30 for i in top)

    lines = []
    for i in top:
        lines.append(f"{i.get('invoice_id')} — €{i.get('amount')} — {i.get('days_overdue')} days overdue")

    email_draft = (
        f"Subject: Payment reminder

"
        f"Hi {customer},

"
        f"Hope you're well. A quick reminder that the following invoices are now overdue:
"
        + "
".join(f"- {ln}" for ln in lines)
        + "

Could you confirm the payment date? If anything is blocked on your side, tell me and I’ll help resolve it.

"
        f"Thanks,
"
    )

    return {
        "prioritised_invoices": top,
        "email_draft": email_draft,
        "escalation_flag": escalation,
    }
