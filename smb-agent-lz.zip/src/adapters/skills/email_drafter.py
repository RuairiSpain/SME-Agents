from __future__ import annotations

from typing import Any, Dict, List


def EmailDrafter(arguments: Dict[str, Any]) -> Dict[str, Any]:
    recipient = arguments["recipient"]
    intent = arguments["intent"]
    bullets = arguments.get("bullets", [])

    body_lines = [f"Hi {recipient},", "", intent + ":"]
    if bullets:
        body_lines.extend([f"- {b}" for b in bullets])
    body_lines.extend(["", "Thanks,", ""])

    return {
        "subject": intent,
        "to": recipient,
        "body": "
".join(body_lines),
    }
