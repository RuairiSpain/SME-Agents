from __future__ import annotations

from typing import Any, Dict

from src.storage.state_store import JsonStateStore

STORE = JsonStateStore("data/state.json")


def get_memory(arguments: Dict[str, Any] | None = None) -> Dict[str, Any]:
    return STORE.get()


def update_memory(arguments: Dict[str, Any]) -> Dict[str, Any]:
    patch = arguments["patch"]
    return STORE.update(patch)
