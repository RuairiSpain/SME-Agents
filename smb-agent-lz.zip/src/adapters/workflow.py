from __future__ import annotations

import datetime
import json
import os
from typing import Any, Dict

import yaml

from src.registry.tool_registry import ToolRegistry
from src.orchestrator.agents import FinanceAgent, CommsAgent, OrchestratorAgent

TOOLS_PATH = "config/tools.yaml"
WF_PATH = "config/workflows.yaml"


def _load_workflow(name: str) -> Dict[str, Any]:
    with open(WF_PATH, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    wf = data.get("workflows", {}).get(name)
    if not wf:
        raise KeyError(f"Unknown workflow: {name}")
    return wf


def _resolve(value: Any, ctx: Dict[str, Any]):
    # Minimal templating for ${key.subkey}
    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
        expr = value[2:-1]
        parts = expr.split(".")
        cur = ctx
        for p in parts:
            cur = cur[p]
        return cur
    if isinstance(value, dict):
        return {k: _resolve(v, ctx) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve(v, ctx) for v in value]
    return value


def run_workflow(arguments: Dict[str, Any]) -> Dict[str, Any]:
    name = arguments["workflow"]
    inputs = arguments.get("inputs", {})
    wf = _load_workflow(name)

    reg = ToolRegistry(TOOLS_PATH)

    ctx: Dict[str, Any] = {
        "inputs": {
            # defaults
            "owner_email": inputs.get("owner_email", "owner@example.com"),
            "activities": inputs.get("activities", ["Followed up 3 leads", "Published a new offer"]),
            "invoices": inputs.get("invoices", []),
            "customer_name": inputs.get("customer_name", "Customer"),
        },
        "tool_calls": {},
    }

    trace = {
        "workflow": name,
        "started": datetime.datetime.utcnow().isoformat() + "Z",
        "steps": [],
    }

    for step in wf.get("steps", []):
        tool_name = step["tool"]
        tool_def = reg.get_tool(tool_name)
        call_args = step.get("args", {})
        call_args = _resolve(call_args, ctx)

        # Call adapter
        adapter = reg.load_callable(tool_def.adapter)
        # adapters may be functions
        if callable(adapter):
            out = adapter(call_args if call_args != {} else (call_args or {}))
        else:
            out = adapter

        save_as = step.get("save_as")
        if save_as:
            ctx["tool_calls"][save_as] = out
            ctx[save_as] = out

        trace["steps"].append({"tool": tool_name, "args": call_args, "output": out})

    # Multi-agent post-processing
    agents = OrchestratorAgent([FinanceAgent(), CommsAgent()])
    agent_out = agents.run(ctx).output

    trace["agents"] = agent_out
    trace["finished"] = datetime.datetime.utcnow().isoformat() + "Z"

    os.makedirs("data/traces", exist_ok=True)
    trace_path = os.path.join("data/traces", f"{name}.jsonl")
    with open(trace_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(trace, ensure_ascii=False) + "
")

    return {
        "workflow": name,
        "result": ctx.get("tool_calls", {}),
        "agents": agent_out,
        "trace_file": trace_path,
    }
