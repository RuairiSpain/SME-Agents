from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class JsonRpcError(Exception):
    code: int
    message: str
    data: Any = None

    def to_dict(self) -> Dict[str, Any]:
        err = {"code": self.code, "message": self.message}
        if self.data is not None:
            err["data"] = self.data
        return err


def make_result(id_: Any, result: Any) -> Dict[str, Any]:
    return {"jsonrpc": "2.0", "id": id_, "result": result}


def make_error(id_: Any, err: JsonRpcError) -> Dict[str, Any]:
    return {"jsonrpc": "2.0", "id": id_, "error": err.to_dict()}


def get_id(payload: Dict[str, Any]) -> Any:
    return payload.get("id")


def get_method(payload: Dict[str, Any]) -> str:
    method = payload.get("method")
    if not method:
        raise JsonRpcError(-32600, "Invalid Request", {"reason": "Missing method"})
    return method


def get_params(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    params = payload.get("params")
    if params is None:
        return None
    if not isinstance(params, dict):
        raise JsonRpcError(-32602, "Invalid params", {"reason": "params must be an object"})
    return params
