from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Dict, List

import yaml
from jsonschema import validate, ValidationError


@dataclass
class ToolDef:
    name: str
    title: str
    description: str
    adapter: str
    input_schema: Dict[str, Any]


class ToolRegistry:
    def __init__(self, tools_yaml_path: str):
        with open(tools_yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        self._tools: Dict[str, ToolDef] = {}
        for t in data.get("tools", []):
            td = ToolDef(
                name=t["name"],
                title=t.get("title", t["name"]),
                description=t.get("description", ""),
                adapter=t["adapter"],
                input_schema=t.get("inputSchema", {"type": "object", "properties": {}}),
            )
            self._tools[td.name] = td

    def list_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": td.name,
                "title": td.title,
                "description": td.description,
                "inputSchema": td.input_schema,
            }
            for td in self._tools.values()
        ]

    def get_tool(self, name: str) -> ToolDef:
        if name not in self._tools:
            raise KeyError(name)
        return self._tools[name]

    def validate_args(self, tool: ToolDef, arguments: Dict[str, Any]) -> None:
        try:
            validate(instance=arguments, schema=tool.input_schema)
        except ValidationError as e:
            raise ValueError(str(e))

    def load_callable(self, adapter_path: str):
        """Load an adapter callable from 'module.path:callable_name'."""
        if ":" in adapter_path:
            mod, attr = adapter_path.split(":", 1)
        else:
            mod, attr = adapter_path, None
        module = importlib.import_module(mod)
        if not attr:
            return module
        target = module
        for part in attr.split("."):
            target = getattr(target, part)
        return target
