from __future__ import annotations

import os
from typing import Any, Dict, Optional

from fastapi import FastAPI, Request

from src.mcp_runtime.jsonrpc import JsonRpcError, make_error, make_result, get_id, get_method, get_params
from src.registry.tool_registry import ToolRegistry

TOOLS_PATH = os.getenv("MCP_TOOLS_PATH", "config/tools.yaml")

app = FastAPI(title="SMB MCP Server", version="0.1.0")
registry = ToolRegistry(TOOLS_PATH)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/mcp")
async def mcp(request: Request):
    payload = await request.json()
    id_ = get_id(payload)

    try:
        method = get_method(payload)
        params = get_params(payload)

        if method == "initialize":
            client_caps = (params or {}).get("capabilities", {})
            proto = (params or {}).get("protocolVersion", "2024-11-05")
            return make_result(
                id_,
                {
                    "protocolVersion": proto,
                    "capabilities": {
                        "tools": {"listChanged": False},
                        "resources": {"subscribe": False, "listChanged": False},
                        "prompts": {"listChanged": False},
                    },
                    "serverInfo": {"name": "smb-mcp-server", "version": app.version},
                },
            )

        if method == "tools/list":
            cursor = (params or {}).get("cursor")
            tools = registry.list_tools()
            return make_result(id_, {"tools": tools, "nextCursor": None})

        if method == "tools/call":
            if not params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing params"})
            name = params.get("name")
            arguments = params.get("arguments", {})
            if not name:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing tool name"})

            try:
                tool = registry.get_tool(name)
            except KeyError:
                raise JsonRpcError(-32601, "Method not found", {"tool": name})

            # Validate
            try:
                registry.validate_args(tool, arguments)
            except ValueError as e:
                raise JsonRpcError(-32602, "Invalid params", {"tool": name, "error": str(e)})

            adapter = registry.load_callable(tool.adapter)
            try:
                output = adapter(arguments)
                return make_result(
                    id_,
                    {
                        "content": [{"type": "text", "text": _as_text(output)}],
                        "isError": False,
                    },
                )
            except Exception as e:
                return make_result(
                    id_,
                    {
                        "content": [{"type": "text", "text": f"Tool error: {e}"}],
                        "isError": True,
                    },
                )

        if method == "resources/list":
            resources = [
                {
                    "uri": "memory://global",
                    "name": "global-memory",
                    "title": "Global Cross-Skill Memory",
                    "description": "Shared state persisted by the server.",
                    "mimeType": "application/json",
                },
                {
                    "uri": "file://config/bindings.yaml",
                    "name": "bindings",
                    "title": "Connector Bindings",
                    "description": "Mappings from connectors to global state.",
                    "mimeType": "text/yaml",
                },
            ]
            return make_result(id_, {"resources": resources, "nextCursor": None})

        if method == "resources/read":
            if not params or "uri" not in params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing uri"})
            uri = params["uri"]
            if uri == "memory://global":
                mem_tool = registry.get_tool("memory.get")
                adapter = registry.load_callable(mem_tool.adapter)
                mem = adapter({})
                return make_result(id_, {"contents": [{"uri": uri, "mimeType": "application/json", "text": _as_text(mem)}]})
            if uri.startswith("file://"):
                path = uri[len("file://"):]
                if not os.path.exists(path):
                    raise JsonRpcError(-32004, "Resource not found", {"uri": uri})
                with open(path, "r", encoding="utf-8") as f:
                    text = f.read()
                mime = "text/plain"
                if path.endswith(".yaml") or path.endswith(".yml"):
                    mime = "text/yaml"
                if path.endswith(".json"):
                    mime = "application/json"
                return make_result(id_, {"contents": [{"uri": uri, "mimeType": mime, "text": text}]})
            raise JsonRpcError(-32004, "Resource not found", {"uri": uri})

        if method == "prompts/list":
            prompts = [
                {
                    "name": "weekly_review",
                    "title": "Weekly Review",
                    "description": "Guides the agent to run the weekly-review workflow and summarise outputs.",
                    "arguments": [
                        {"name": "owner_email", "description": "Owner email", "required": True},
                    ],
                }
            ]
            return make_result(id_, {"prompts": prompts, "nextCursor": None})

        if method == "prompts/get":
            if not params or "name" not in params:
                raise JsonRpcError(-32602, "Invalid params", {"reason": "Missing name"})
            name = params["name"]
            args = (params or {}).get("arguments", {})
            if name != "weekly_review":
                raise JsonRpcError(-32004, "Prompt not found", {"name": name})
            owner = args.get("owner_email", "owner@example.com")
            return make_result(
                id_,
                {
                    "description": "Weekly review prompt",
                    "messages": [
                        {
                            "role": "user",
                            "content": {
                                "type": "text",
                                "text": f"Run workflow.run with workflow=weekly-review and inputs.owner_email={owner}. Then summarise the pulse, brief and email draft in 5 bullets.",
                            },
                        }
                    ],
                },
            )

        raise JsonRpcError(-32601, "Method not found", {"method": method})

    except JsonRpcError as e:
        return make_error(id_, e)


def _as_text(obj: Any) -> str:
    # Compact but readable
    import json

    if isinstance(obj, str):
        return obj
    return json.dumps(obj, ensure_ascii=False, indent=2)
