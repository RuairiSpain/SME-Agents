# SMB Agent Landing Zone — MCP + Multi-Agent Orchestrator

A practical, runnable reference repo for:

- **MCP server** (JSON-RPC 2.0 over HTTP) exposing tools/resources/prompts
- **Tool registry** driven by `config/tools.yaml`
- **Cross-skill memory** persisted to `data/state.json`
- **Evaluation framework** (deterministic rubric, swap-in LLM judging later)
- **Multi-agent orchestrator** (`workflow.run`) executing workflows from `config/workflows.yaml`
- **Connector bindings** (`config/bindings.yaml`) mapping external systems to global state

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
chmod +x scripts/start.sh
./scripts/start.sh
```

Server endpoints:
- MCP: `POST http://127.0.0.1:8000/mcp`
- Health: `GET  http://127.0.0.1:8000/health`

## Test MCP

```bash
chmod +x scripts/test_mcp.sh
./scripts/test_mcp.sh
```

## VS Code MCP config

Copy `examples/vscode-mcp/mcp.json` to `.vscode/mcp.json`.

## Workflows

- `weekly-review`
- `invoice-ops`

Run via MCP:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "workflow.run",
    "arguments": {
      "workflow": "weekly-review",
      "inputs": {"owner_email": "owner@example.com"}
    }
  }
}
```

## Notes

- Connectors are simulated stubs for now.
- Replace connector adapters with real API calls when ready.
