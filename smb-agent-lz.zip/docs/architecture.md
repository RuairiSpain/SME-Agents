# Architecture

This repo follows a layered pattern:

Client (VS Code / Copilot Studio / other MCP host)
→ MCP JSON-RPC endpoint (`POST /mcp`)
→ Registry (`config/tools.yaml`)
→ Adapters (skills, connectors, memory, evaluation)
→ Orchestrator (multi-agent workflow runner)

Key MCP methods implemented:
- initialize
- tools/list
- tools/call
- resources/list
- resources/read
- prompts/list
- prompts/get

See the MCP spec pages for tools/resources/prompts.
