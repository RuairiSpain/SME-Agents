# Operating Rules

- Be concise, actionable, and business-focused.
- Optimise for small business simplicity and ROI.
- Prefer deterministic outputs with explicit schemas.
