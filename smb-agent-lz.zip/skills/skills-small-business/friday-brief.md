# Friday Brief

## Purpose
Concise weekly executive summary.

## Inputs
- activities: array
- metrics: object

## Outputs
- bullets: list[string]
- metrics: object

## Steps
1. Summarise wins
2. Highlight risks
3. Set next-week priorities
