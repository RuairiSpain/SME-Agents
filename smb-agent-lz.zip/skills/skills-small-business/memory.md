# Session Memory (Skill Pack)

Use this for short-lived conversational context:
- what the user asked
- decisions made
- draft outputs

Do **not** store secrets.
