# Business Pulse

## Purpose
Weekly health snapshot across revenue, pipeline, and cash.

## Inputs
- revenue_data: array
- pipeline_data: array
- cash_balance: number

## Outputs
- summary: string
- risks: list[string]
- actions: list[string]

## Steps
1. Analyse trends
2. Identify risks
3. Recommend actions

## Example
Input: cash_balance=800
Output: risk="Cash buffer is low", action="Run invoice chase"

## Observability
- Log input sizes and cash threshold decisions
