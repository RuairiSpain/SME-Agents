# Invoice Chase

## Purpose
Prioritised follow-up for overdue invoices.

## Inputs
- invoices: array
- customer_name: string

## Outputs
- prioritised_invoices: array
- email_draft: string
- escalation_flag: boolean

## Steps
1. Filter overdue invoices
2. Sort by days overdue then amount
3. Draft a polite but firm reminder

## Observability
- Capture which invoices were selected
- Record escalation trigger
