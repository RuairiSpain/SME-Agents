# Email Drafter

## Purpose
Draft short, professional emails.

## Inputs
- recipient: string
- intent: string
- bullets: array (optional)

## Outputs
- subject: string
- to: string
- body: string
