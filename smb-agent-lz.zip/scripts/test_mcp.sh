#!/usr/bin/env bash
set -euo pipefail

echo "== initialize =="
curl -s -X POST http://127.0.0.1:8000/mcp -H 'Content-Type: application/json' -d '{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "curl", "version": "0"}}
}' | python -m json.tool

echo "== tools/list =="
curl -s -X POST http://127.0.0.1:8000/mcp -H 'Content-Type: application/json' -d '{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/list",
  "params": {}
}' | python -m json.tool

echo "== workflow.run =="
curl -s -X POST http://127.0.0.1:8000/mcp -H 'Content-Type: application/json' -d '{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {"name": "workflow.run", "arguments": {"workflow": "weekly-review", "inputs": {"owner_email": "owner@example.com"}}}
}' | python -m json.tool
